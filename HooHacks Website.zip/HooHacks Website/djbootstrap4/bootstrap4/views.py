from django.shortcuts import render
import requests
import cv2
import matplotlib.pyplot as plt 
import cvlib as cv
from cvlib.object_detection import draw_bbox
import pandas as pd
from pytrends.request import TrendReq
import emoji
import nltk
nltk.download('wordnet')
from nltk.corpus import wordnet as wn
# Create your views here.
def bootstrap4_index(request):
	print('hi')
	return render(request, 'index.html', {})

def calcscore(request):
	print('atleast im getting here')
	im = cv2.imread('/Users/aishuakku/Desktop/HooHacks Website/djbootstrap4/bootstrap4/fashionable.jpeg')
	print('im getting here too')
	bbox, label, conf = cv.detect_common_objects(im)
	print('im getting here three')
	output_image = draw_bbox(im, bbox, label, conf)
	things = list(set(label))
	print(things)
	pytrends = TrendReq()
	kw_list =things#[things[0]] #["person"]
	pytrends.build_payload(kw_list)
	df = pytrends.get_historical_interest(kw_list, year_start=2021, month_start=2, day_start=1, hour_start=0, year_end=2021, month_end=2, day_end=1, hour_end=1, cat=0, geo='', gprop='', sleep=0)
	print()
	count=0
	maxval=0
	maxword = ''
	for i in df:
		if df[i].mean()>maxval:
			maxval=df[i].mean()
			maxword=i
		count+=df[i].mean()
	print('this is the max word')
	print(maxword)
	final=count/100
	file = open("/Users/aishuakku/Desktop/HooHacks Website/djbootstrap4/bootstrap4/hoohacksquotes.txt", encoding="utf8")
	myList = []
	for line in file:
	    s = line.split("\n")
	    myList.append(s)
	label = things
	popWord = maxword
	for ss in wn.synsets(popWord):
		for w in ss.lemma_names():
			label.append(w)
	print('this is working properly')
	allQuotes = set()
	label = list(set(label))
	for ex in label:
		possQuotes = {item[0] for item in myList if ex in item[0].split()}
		if possQuotes:
			for quote in possQuotes:
				allQuotes.add(quote)
	finalquotes=''
	print('this is all quotes'+str(allQuotes))
	'''for word in things:
	    if word not in emoji.emojize(':' + word + ':', use_aliases=True): 
	    	print('this is the emoji'+emoji.emojize(':' + word + ':', use_aliases=True), end='')'''


	'''file = open("hoohacksquotes.txt", encoding="utf8")
	myList = []
	for line in file:
	    s = line.split("\n")
	    myList.append(s)
	for ex in things:
	    possQuotes = [item for item in myList if (" " + ex + " ") in (str(item))]
	    for quote in possQuotes:
	        print(quote[0].replace("\"", ""))'''
	'''count=0
	s=0
	for i in df:
		s+=df[i].mean()
		if df[i].mean()!=0:
			count+=1
	print('avg '+str((s/count)))
	final = s/count'''
	return render(request, 'index.html', {'data':final, 'quotes':allQuotes})

