from django.apps import AppConfig


class Bootstrap4Config(AppConfig):
    name = 'bootstrap4'
